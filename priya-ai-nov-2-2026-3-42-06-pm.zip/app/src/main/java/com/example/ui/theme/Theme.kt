package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.example.R

val PriyaElectricBlue = Color(0xFF1E88E5)
val PriyaBrightBlue = Color(0xFF2979FF)
val PriyaCyanGlow = Color(0xFF40C4FF)
val PriyaNavyButton = Color(0xFF0A1428)
val PriyaTopSlate = Color(0xFF232834)
val PriyaMistCenter = Color(0xFFCFD2D8)
val PriyaBottomDark = Color(0xFF151924)
val PriyaSurfaceCard = Color(0xFF161C2C)
val PriyaVioletAccent = Color(0xFFB388FF)

val PoppinsFontFamily = FontFamily(
    Font(R.font.poppins, FontWeight.Normal),
    Font(R.font.poppins, FontWeight.Medium),
    Font(R.font.poppins, FontWeight.SemiBold),
    Font(R.font.poppins, FontWeight.Bold)
)

val PlayfairFontFamily = FontFamily(
    Font(R.font.playfair_display, FontWeight.Normal, FontStyle.Italic),
    Font(R.font.playfair_display, FontWeight.Medium)
)

private val PriyaDarkColorScheme = darkColorScheme(
    primary = PriyaBrightBlue,
    onPrimary = Color.White,
    primaryContainer = PriyaNavyButton,
    onPrimaryContainer = PriyaCyanGlow,
    secondary = PriyaCyanGlow,
    onSecondary = Color(0xFF051020),
    tertiary = PriyaVioletAccent,
    background = PriyaBottomDark,
    onBackground = Color.White,
    surface = PriyaSurfaceCard,
    onSurface = Color.White,
    surfaceVariant = Color(0xFF1F273B),
    onSurfaceVariant = Color(0xFFB8C4DC)
)

val PriyaTypography = Typography(
    displayMedium = TextStyle(
        fontFamily = PoppinsFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 38.sp,
        lineHeight = 44.sp,
        letterSpacing = (-0.5).sp
    ),
    headlineMedium = TextStyle(
        fontFamily = PlayfairFontFamily,
        fontWeight = FontWeight.Normal,
        fontStyle = FontStyle.Italic,
        fontSize = 20.sp,
        lineHeight = 26.sp,
        letterSpacing = 0.3.sp
    ),
    titleLarge = TextStyle(
        fontFamily = PoppinsFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 20.sp,
        lineHeight = 28.sp
    ),
    titleMedium = TextStyle(
        fontFamily = PoppinsFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 22.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = PoppinsFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 15.sp,
        lineHeight = 22.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = PoppinsFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp,
        lineHeight = 19.sp
    ),
    labelLarge = TextStyle(
        fontFamily = PoppinsFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp
    )
)

@Composable
fun PriyaAITheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = PriyaDarkColorScheme,
        typography = PriyaTypography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    PriyaAITheme(content = content)
}
