package com.example

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import androidx.annotation.DrawableRes
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.content
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import org.json.JSONObject
import java.util.Locale
import java.util.UUID

private const val TAG = "PriyaViewModel"

private val Context.priyaDataStore by preferencesDataStore(name = "priya_preferences")

enum class PriyaAvatar(
    val id: Int,
    val title: String,
    val subtitle: String,
    @DrawableRes val drawableRes: Int
) {
    CASUAL(
        id = 0,
        title = "Casual Breeze",
        subtitle = "Ponytail, white graphic tee & denim shorts",
        drawableRes = R.drawable.priya_avatar_casual
    ),
    STREET(
        id = 1,
        title = "Chic Street",
        subtitle = "Short bob, striped top, plaid skirt & crossbody bag",
        drawableRes = R.drawable.priya_avatar_street
    ),
    FORMAL(
        id = 2,
        title = "Executive Noir",
        subtitle = "Wavy bob & tailored black blazer suit",
        drawableRes = R.drawable.priya_avatar_formal
    );

    companion object {
        fun fromId(id: Int): PriyaAvatar = entries.firstOrNull { it.id == id } ?: CASUAL
    }
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: Sender,
    val text: String,
    val actionBadge: String? = null,
    val timestamp: Long = System.currentTimeMillis()
) {
    enum class Sender { USER, PRIYA, SYSTEM }
}

sealed interface PriyaVoiceState {
    data object Idle : PriyaVoiceState
    data class Listening(val partialText: String = "", val rmsDb: Float = 0f) : PriyaVoiceState
    data class Thinking(val query: String) : PriyaVoiceState
    data class Speaking(val reply: String) : PriyaVoiceState
    data class Error(val message: String) : PriyaVoiceState
}

class PriyaViewModel(application: Application) : AndroidViewModel(application) {

    private val appContext = application.applicationContext

    private val KEY_AVATAR_ID = intPreferencesKey("selected_avatar_id")
    private val KEY_AUTO_SPEAK = booleanPreferencesKey("auto_speak_enabled")
    private val KEY_LANGUAGE_MODE = stringPreferencesKey("language_mode")

    private val _selectedAvatar = MutableStateFlow(PriyaAvatar.CASUAL)
    val selectedAvatar: StateFlow<PriyaAvatar> = _selectedAvatar.asStateFlow()

    private val _autoSpeak = MutableStateFlow(true)
    val autoSpeak: StateFlow<Boolean> = _autoSpeak.asStateFlow()

    private val _languageMode = MutableStateFlow("Hinglish / Multi")
    val languageMode: StateFlow<String> = _languageMode.asStateFlow()

    private val _voiceState = MutableStateFlow<PriyaVoiceState>(PriyaVoiceState.Idle)
    val voiceState: StateFlow<PriyaVoiceState> = _voiceState.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = ChatMessage.Sender.PRIYA,
                text = "Namaste! Main Priya hoon — Your Voice, My World. Tap the mic to speak, open Vision camera, or tell me to open any app, read your screen, or call someone!"
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _lastAssistantBubble = MutableStateFlow<String?>(null)
    val lastAssistantBubble: StateFlow<String?> = _lastAssistantBubble.asStateFlow()

    fun dismissAssistantBubble() {
        _lastAssistantBubble.value = null
    }

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _contacts = MutableStateFlow<List<ContactEntry>>(emptyList())
    val contacts: StateFlow<List<ContactEntry>> = _contacts.asStateFlow()

    private var tts: TextToSpeech? = null
    private var isTtsReady = false
    private var speechRecognizer: SpeechRecognizer? = null

    private val assistantSchema = Schema.obj(
        properties = mapOf(
            "spokenReply" to Schema.string(
                description = "Warm, conversational reply from Priya in the user's preferred language (Hinglish, Hindi, Bengali, or English). Keep it concise and natural to speak aloud."
            ),
            "commandType" to Schema.enumeration(
                values = listOf(
                    "NONE",
                    "OPEN_APP",
                    "CALL_CONTACT",
                    "READ_SCREEN",
                    "CLICK_TEXT",
                    "SCROLL_DOWN",
                    "SCROLL_UP",
                    "GO_HOME",
                    "GO_BACK",
                    "OPEN_NOTIFICATIONS",
                    "VOLUME_UP",
                    "VOLUME_DOWN",
                    "CHANGE_AVATAR"
                ),
                description = "Device action to execute if the user asked to control the phone."
            ),
            "commandTarget" to Schema.string(
                description = "App name to open, contact/phone number to call, text on screen to click, or avatar style ('casual', 'street', 'formal'). Empty string if NONE."
            )
        )
    )

    private val structuredModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = assistantSchema
            },
            systemInstruction = content {
                text(
                    """
                    You are Priya (Priya AI), a smart, warm, expressive personal AI companion and Android phone controller.
                    Your tagline is "Your Voice, My World".
                    You understand and speak English, Hindi, Hinglish, and Bengali fluently. Match the language/script or Hinglish style of the user.
                    You have 3 avatar outfits:
                    1. 'casual' (Casual Breeze - ponytail, white t-shirt, denim shorts)
                    2. 'street' (Chic Street - short bob, striped top, plaid skirt, crossbody bag)
                    3. 'formal' (Executive Noir - wavy bob, black blazer suit)
                    You can control the user's Android phone using Accessibility & Intents:
                    - Open installed apps (commandType = OPEN_APP, commandTarget = app name)
                    - Call a contact or number (commandType = CALL_CONTACT, commandTarget = contact name or digits)
                    - Read the screen aloud (commandType = READ_SCREEN)
                    - Click a button/text on screen (commandType = CLICK_TEXT, commandTarget = label)
                    - Scroll screen down/up (commandType = SCROLL_DOWN or SCROLL_UP)
                    - Navigate Home, Back, or Notifications (GO_HOME, GO_BACK, OPEN_NOTIFICATIONS)
                    - Adjust volume (VOLUME_UP, VOLUME_DOWN)
                    - Switch your outfit/avatar (CHANGE_AVATAR, commandTarget = casual / street / formal)
                    Always respond warmly as Priya in 'spokenReply'.
                    """.trimIndent()
                )
            }
        )
    }

    private val visionModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash"
        )
    }

    init {
        loadPreferences()
        initTextToSpeech()
        refreshDeviceData()
    }

    private fun loadPreferences() {
        viewModelScope.launch {
            try {
                val prefs = appContext.priyaDataStore.data.first()
                _selectedAvatar.value = PriyaAvatar.fromId(prefs[KEY_AVATAR_ID] ?: 0)
                _autoSpeak.value = prefs[KEY_AUTO_SPEAK] ?: true
                _languageMode.value = prefs[KEY_LANGUAGE_MODE] ?: "Hinglish / Multi"
            } catch (e: Exception) {
                Log.w(TAG, "Failed to load preferences", e)
            }
        }
    }

    fun selectAvatar(avatar: PriyaAvatar) {
        _selectedAvatar.value = avatar
        viewModelScope.launch {
            try {
                appContext.priyaDataStore.edit { prefs ->
                    prefs[KEY_AVATAR_ID] = avatar.id
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed to save avatar preference", e)
            }
        }
    }

    fun cycleAvatar(forward: Boolean = true) {
        val entries = PriyaAvatar.entries
        val currentIdx = entries.indexOf(_selectedAvatar.value)
        val nextIdx = if (forward) {
            (currentIdx + 1) % entries.size
        } else {
            (currentIdx - 1 + entries.size) % entries.size
        }
        selectAvatar(entries[nextIdx])
    }

    fun toggleAutoSpeak(enabled: Boolean) {
        _autoSpeak.value = enabled
        if (!enabled) {
            tts?.stop()
            if (_voiceState.value is PriyaVoiceState.Speaking) {
                _voiceState.value = PriyaVoiceState.Idle
            }
        }
        viewModelScope.launch {
            appContext.priyaDataStore.edit { it[KEY_AUTO_SPEAK] = enabled }
        }
    }

    fun setLanguageMode(mode: String) {
        _languageMode.value = mode
        viewModelScope.launch {
            appContext.priyaDataStore.edit { it[KEY_LANGUAGE_MODE] = mode }
        }
    }

    fun refreshDeviceData() {
        viewModelScope.launch {
            _installedApps.value = DeviceController.getInstalledLauncherApps(appContext)
            _contacts.value = DeviceController.queryContacts(appContext)
        }
    }

    private fun initTextToSpeech() {
        tts = TextToSpeech(appContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val hiResult = tts?.setLanguage(Locale("en", "IN"))
                if (hiResult == TextToSpeech.LANG_MISSING_DATA || hiResult == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts?.language = Locale.US
                }
                tts?.setPitch(1.08f)
                tts?.setSpeechRate(1.0f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (_voiceState.value is PriyaVoiceState.Speaking) {
                            _voiceState.value = PriyaVoiceState.Idle
                        }
                    }

                    override fun onError(utteranceId: String?) {
                        if (_voiceState.value is PriyaVoiceState.Speaking) {
                            _voiceState.value = PriyaVoiceState.Idle
                        }
                    }
                })
                isTtsReady = true
            }
        }
    }

    fun speakText(text: String) {
        if (!_autoSpeak.value || !isTtsReady || text.isBlank()) {
            _voiceState.value = PriyaVoiceState.Idle
            return
        }
        _voiceState.value = PriyaVoiceState.Speaking(text)
        val params = Bundle()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, params, "priya_utt_${System.currentTimeMillis()}")
    }

    fun stopSpeakingOrListening() {
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.cancel()
        } catch (_: Exception) {
        }
        tts?.stop()
        _voiceState.value = PriyaVoiceState.Idle
    }

    fun startVoiceListening() {
        tts?.stop()
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            val msg = "Voice recognition service is unavailable on this emulator/device. Use the chat icon or quick voice chips below!"
            _voiceState.value = PriyaVoiceState.Error(msg)
            _lastAssistantBubble.value = msg
            return
        }

        try {
            if (speechRecognizer == null) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(appContext)
            }
            speechRecognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    _voiceState.value = PriyaVoiceState.Listening(partialText = "Listening...")
                }

                override fun onBeginningOfSpeech() {
                    _voiceState.value = PriyaVoiceState.Listening(partialText = "Speak now...")
                }

                override fun onRmsChanged(rmsdB: Float) {
                    val current = _voiceState.value
                    if (current is PriyaVoiceState.Listening) {
                        _voiceState.value = current.copy(rmsDb = rmsdB.coerceIn(0f, 12f))
                    }
                }

                override fun onBufferReceived(buffer: ByteArray?) {}

                override fun onEndOfSpeech() {}

                override fun onError(error: Int) {
                    val errorDesc = when (error) {
                        SpeechRecognizer.ERROR_NO_MATCH -> "Didn't catch that. Tap the mic to try again!"
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No speech detected. Tap the mic to speak."
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is required."
                        else -> "Voice input paused (code $error). You can also type or tap a command."
                    }
                    _voiceState.value = PriyaVoiceState.Idle
                    _lastAssistantBubble.value = errorDesc
                }

                override fun onResults(results: Bundle?) {
                    val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = matches?.firstOrNull()?.trim().orEmpty()
                    if (spoken.isNotEmpty()) {
                        sendUserCommandOrMessage(spoken)
                    } else {
                        _voiceState.value = PriyaVoiceState.Idle
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) {
                    val partial = partialResults
                        ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()
                        .orEmpty()
                    if (partial.isNotEmpty()) {
                        _voiceState.value = PriyaVoiceState.Listening(partialText = partial)
                    }
                }

                override fun onEvent(eventType: Int, params: Bundle?) {}
            })

            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(
                    RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                )
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            }
            _voiceState.value = PriyaVoiceState.Listening(partialText = "Initializing mic...")
            speechRecognizer?.startListening(recognizerIntent)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start SpeechRecognizer", e)
            _voiceState.value = PriyaVoiceState.Error(
                "Could not start microphone: ${e.localizedMessage}"
            )
        }
    }

    fun sendUserCommandOrMessage(userText: String) {
        val cleanText = userText.trim()
        if (cleanText.isEmpty()) return

        _messages.value = _messages.value + ChatMessage(
            sender = ChatMessage.Sender.USER,
            text = cleanText
        )
        _voiceState.value = PriyaVoiceState.Thinking(cleanText)
        _lastAssistantBubble.value = "Thinking..."

        viewModelScope.launch {
            try {
                val installedSummary = _installedApps.value.take(25).joinToString(", ") { it.label }
                val accActive = PriyaAccessibility.isConnected.value
                val contextPrompt = buildString {
                    appendLine("User language preference: ${_languageMode.value}")
                    appendLine("Current outfit: ${_selectedAvatar.value.title}")
                    appendLine("Accessibility service connected: $accActive")
                    if (installedSummary.isNotEmpty()) {
                        appendLine("Sample installed apps on phone: $installedSummary")
                    }
                    appendLine("User says: $cleanText")
                }

                val response = withTimeout(60_000L) {
                    structuredModel.generateContent(contextPrompt)
                }

                val rawJson = response.text
                if (rawJson.isNullOrBlank()) {
                    throw IllegalStateException("Priya returned an empty response.")
                }

                val json = JSONObject(rawJson)
                val spokenReply = json.optString("spokenReply", "Main samajh gayi!").trim()
                val commandType = json.optString("commandType", "NONE").trim()
                val commandTarget = json.optString("commandTarget", "").trim()

                val actionOutcome = executeDeviceCommand(commandType, commandTarget)
                val finalReply = if (actionOutcome != null) {
                    "$spokenReply\n($actionOutcome)"
                } else {
                    spokenReply
                }

                _messages.value = _messages.value + ChatMessage(
                    sender = ChatMessage.Sender.PRIYA,
                    text = spokenReply,
                    actionBadge = actionOutcome
                )
                _lastAssistantBubble.value = finalReply
                speakText(spokenReply)
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI generation timed out", e)
                val errMsg = "Request timed out after 60 seconds. Please try again."
                _voiceState.value = PriyaVoiceState.Error(errMsg)
                _lastAssistantBubble.value = errMsg
                _messages.value = _messages.value + ChatMessage(
                    sender = ChatMessage.Sender.SYSTEM,
                    text = errMsg
                )
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Firebase AI generation failed", e)
                val errMsg = e.localizedMessage ?: "Failed to connect to Priya AI."
                _voiceState.value = PriyaVoiceState.Error(errMsg)
                _lastAssistantBubble.value = errMsg
                _messages.value = _messages.value + ChatMessage(
                    sender = ChatMessage.Sender.SYSTEM,
                    text = "Error: $errMsg"
                )
            }
        }
    }

    fun analyzeCameraImage(bitmap: Bitmap, question: String) {
        val promptText = question.ifBlank {
            "Describe what you see in this image warmly as Priya in ${_languageMode.value}, and read any visible text."
        }
        _messages.value = _messages.value + ChatMessage(
            sender = ChatMessage.Sender.USER,
            text = "📷 [Camera Vision] $promptText"
        )
        _voiceState.value = PriyaVoiceState.Thinking("Analyzing camera image...")
        _lastAssistantBubble.value = "Looking through camera..."

        viewModelScope.launch {
            try {
                val response = withTimeout(60_000L) {
                    visionModel.generateContent(
                        content {
                            image(bitmap)
                            text(
                                "You are Priya AI ('Your Voice, My World'). Answer the user's request about this image concisely and naturally in ${_languageMode.value}: $promptText"
                            )
                        }
                    )
                }
                val reply = response.text?.trim().orEmpty().ifEmpty {
                    "I saw the photo, but couldn't describe it clearly."
                }
                _messages.value = _messages.value + ChatMessage(
                    sender = ChatMessage.Sender.PRIYA,
                    text = reply,
                    actionBadge = "Camera Vision Analyzed"
                )
                _lastAssistantBubble.value = reply
                speakText(reply)
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Vision analysis timed out", e)
                val msg = "Camera vision timed out after 60 seconds."
                _voiceState.value = PriyaVoiceState.Error(msg)
                _lastAssistantBubble.value = msg
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Vision analysis failed", e)
                val msg = e.localizedMessage ?: "Vision analysis failed."
                _voiceState.value = PriyaVoiceState.Error(msg)
                _lastAssistantBubble.value = msg
            }
        }
    }

    private fun executeDeviceCommand(commandType: String, target: String): String? {
        return when (commandType.uppercase()) {
            "NONE" -> null
            "OPEN_APP" -> {
                val (_, message) = DeviceController.launchAppByNameOrPackage(appContext, target)
                message
            }
            "CALL_CONTACT" -> {
                val (_, message) = DeviceController.callContactOrNumber(appContext, target)
                message
            }
            "READ_SCREEN" -> {
                val acc = PriyaAccessibility.instance
                if (acc != null) {
                    "Screen: ${acc.readScreenText()}"
                } else {
                    "Enable Priya Accessibility Service in Menu to read other app screens."
                }
            }
            "CLICK_TEXT" -> {
                val acc = PriyaAccessibility.instance
                if (acc != null) {
                    val clicked = acc.clickByText(target)
                    if (clicked) "Clicked '$target' on screen." else "Could not find clickable '$target' on screen."
                } else {
                    "Accessibility Service is not active."
                }
            }
            "SCROLL_DOWN" -> {
                val acc = PriyaAccessibility.instance
                if (acc?.performSwipe(directionDown = true) == true) {
                    "Scrolled screen down."
                } else {
                    "Enable Accessibility Service to scroll across apps."
                }
            }
            "SCROLL_UP" -> {
                val acc = PriyaAccessibility.instance
                if (acc?.performSwipe(directionDown = false) == true) {
                    "Scrolled screen up."
                } else {
                    "Enable Accessibility Service to scroll across apps."
                }
            }
            "GO_HOME" -> {
                if (PriyaAccessibility.instance?.navigateHome() == true) {
                    "Navigated to Home screen."
                } else {
                    val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    appContext.startActivity(homeIntent)
                    "Opened Home screen."
                }
            }
            "GO_BACK" -> {
                if (PriyaAccessibility.instance?.navigateBack() == true) {
                    "Pressed Back."
                } else {
                    "Enable Accessibility Service for global Back action."
                }
            }
            "OPEN_NOTIFICATIONS" -> {
                if (PriyaAccessibility.instance?.openNotifications() == true) {
                    "Opened Notification Shade."
                } else {
                    "Enable Accessibility Service to open Notification Shade."
                }
            }
            "VOLUME_UP" -> DeviceController.adjustVolume(appContext, raise = true)
            "VOLUME_DOWN" -> DeviceController.adjustVolume(appContext, raise = false)
            "CHANGE_AVATAR" -> {
                val lower = target.lowercase()
                val avatar = when {
                    lower.contains("street") || lower.contains("skirt") || lower.contains("2") -> PriyaAvatar.STREET
                    lower.contains("formal") || lower.contains("blazer") || lower.contains("suit") || lower.contains("3") -> PriyaAvatar.FORMAL
                    else -> PriyaAvatar.CASUAL
                }
                selectAvatar(avatar)
                "Switched outfit to ${avatar.title}"
            }
            else -> null
        }
    }

    fun toggleForegroundService(enable: Boolean) {
        val serviceIntent = Intent(appContext, PriyaService::class.java)
        if (enable) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    appContext.startForegroundService(serviceIntent)
                } else {
                    appContext.startService(serviceIntent)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Could not start PriyaService", e)
            }
        } else {
            appContext.stopService(serviceIntent)
        }
    }

    override fun onCleared() {
        super.onCleared()
        try {
            speechRecognizer?.destroy()
        } catch (_: Exception) {
        }
        tts?.stop()
        tts?.shutdown()
    }
}
