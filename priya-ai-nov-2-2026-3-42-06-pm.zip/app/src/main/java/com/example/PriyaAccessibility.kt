package com.example

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PriyaAccessibility : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isConnected.value = true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event?.packageName?.toString()?.let { pkg ->
            if (pkg.isNotBlank()) {
                _lastActivePackage.value = pkg
            }
        }
    }

    override fun onInterrupt() {
        // Handle service interrupt gracefully
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) {
            instance = null
        }
        _isConnected.value = false
    }

    /**
     * Reads all visible text on the current screen window hierarchy.
     */
    fun readScreenText(): String {
        val root = rootInActiveWindow ?: return "Screen content unavailable (no active window)."
        val texts = mutableListOf<String>()
        collectNodeText(root, texts)
        return if (texts.isEmpty()) {
            "No readable text found on current screen."
        } else {
            texts.distinct().take(40).joinToString(" • ")
        }
    }

    private fun collectNodeText(node: AccessibilityNodeInfo?, list: MutableList<String>) {
        if (node == null) return
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrEmpty()) {
            list.add(text)
        } else if (!desc.isNullOrEmpty()) {
            list.add(desc)
        }
        for (i in 0 until node.childCount) {
            collectNodeText(node.getChild(i), list)
        }
    }

    /**
     * Finds a clickable element matching [targetText] and clicks it.
     */
    fun clickByText(targetText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val nodes = root.findAccessibilityNodeInfosByText(targetText)
        for (node in nodes) {
            var current: AccessibilityNodeInfo? = node
            while (current != null) {
                if (current.isClickable) {
                    return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                current = current.parent
            }
        }
        return false
    }

    /**
     * Performs a scroll gesture on the active screen.
     */
    fun performSwipe(directionDown: Boolean): Boolean {
        val displayMetrics = resources.displayMetrics
        val centerX = displayMetrics.widthPixels / 2f
        val startY = if (directionDown) displayMetrics.heightPixels * 0.75f else displayMetrics.heightPixels * 0.25f
        val endY = if (directionDown) displayMetrics.heightPixels * 0.25f else displayMetrics.heightPixels * 0.75f

        val path = Path().apply {
            moveTo(centerX, startY)
            lineTo(centerX, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 350L))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun navigateHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun navigateBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun openNotifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun openQuickSettings(): Boolean = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    companion object {
        @Volatile
        var instance: PriyaAccessibility? = null
            private set

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _lastActivePackage = MutableStateFlow("")
        val lastActivePackage: StateFlow<String> = _lastActivePackage.asStateFlow()
    }
}
