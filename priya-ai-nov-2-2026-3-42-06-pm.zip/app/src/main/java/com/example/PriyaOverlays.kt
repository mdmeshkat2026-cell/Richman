package com.example

import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.PriyaBrightBlue
import com.example.ui.theme.PriyaCyanGlow
import com.example.ui.theme.PriyaNavyButton

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PriyaMenuSheet(
    selectedAvatar: PriyaAvatar,
    onSelectAvatar: (PriyaAvatar) -> Unit,
    isAccessibilityConnected: Boolean,
    isServiceRunning: Boolean,
    onToggleService: (Boolean) -> Unit,
    autoSpeak: Boolean,
    onToggleAutoSpeak: (Boolean) -> Unit,
    languageMode: String,
    onSelectLanguageMode: (String) -> Unit,
    installedApps: List<InstalledAppInfo>,
    contacts: List<ContactEntry>,
    onRequestContactsPermission: () -> Unit,
    onSendCommand: (String) -> Unit,
    onClose: () -> Unit
) {
    BackHandler(onBack = onClose)
    val context = LocalContext.current
    val canDrawOverlays = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        Settings.canDrawOverlays(context)
    } else true

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xF50B111E)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.statusBars)
                .windowInsetsPadding(WindowInsets.navigationBars)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp)
        ) {
            // Header with Logo + Title + Close button
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(id = R.drawable.logo),
                        contentDescription = "Priya AI Logo",
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, PriyaCyanGlow, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Priya AI Control Center",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = stringResource(id = R.string.acc_desc),
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFF9EB2D4)
                        )
                    }
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(PriyaNavyButton)
                        .border(1.5.dp, PriyaBrightBlue, CircleShape)
                        .testTag("close_menu_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Menu",
                        tint = Color.White
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Section 1: Avatar Wardrobe Switcher (Matches ui_1, ui_2, ui_3)
            Text(
                text = "Choose Priya's Look (3 Outfits)",
                style = MaterialTheme.typography.titleMedium,
                color = PriyaCyanGlow,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                PriyaAvatar.entries.forEach { avatar ->
                    val isSelected = avatar == selectedAvatar
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onSelectAvatar(avatar) }
                            .border(
                                width = if (isSelected) 2.5.dp else 1.dp,
                                color = if (isSelected) PriyaCyanGlow else PriyaBrightBlue.copy(alpha = 0.35f),
                                shape = RoundedCornerShape(18.dp)
                            )
                            .testTag("avatar_card_${avatar.name.lowercase()}"),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) Color(0xFF17294A) else Color(0xFF131B2E)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Image(
                                painter = painterResource(id = avatar.drawableRes),
                                contentDescription = avatar.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(110.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFFCFD2D8))
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = avatar.title,
                                style = MaterialTheme.typography.labelLarge,
                                color = Color.White,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (isSelected) "Active" else "Tap to wear",
                                style = MaterialTheme.typography.bodyMedium,
                                fontSize = 11.sp,
                                color = if (isSelected) PriyaCyanGlow else Color(0xFF8DA0C4)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Section 2: System Services & Permissions from AndroidManifest.xml
            Text(
                text = "Phone Control & Background Services",
                style = MaterialTheme.typography.titleMedium,
                color = PriyaCyanGlow,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(10.dp))

            // PriyaAccessibility Card
            ServiceStatusCard(
                icon = Icons.Default.AccessibilityNew,
                title = "Priya Accessibility Service",
                subtitle = stringResource(id = R.string.acc_desc),
                isActive = isAccessibilityConnected,
                actionLabel = if (isAccessibilityConnected) "Connected" else "Enable",
                onActionClick = { DeviceController.openAccessibilitySettings(context) },
                testTag = "accessibility_service_card"
            )

            Spacer(modifier = Modifier.height(10.dp))

            // PriyaService Foreground Microphone Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = null,
                            tint = PriyaCyanGlow,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Priya Background Voice Service",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White
                            )
                            Text(
                                text = "Foreground microphone service & wake lock (PriyaService)",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color(0xFF9EB2D4)
                            )
                        }
                    }
                    Switch(
                        checked = isServiceRunning,
                        onCheckedChange = onToggleService,
                        colors = SwitchDefaults.colors(checkedThumbColor = PriyaCyanGlow),
                        modifier = Modifier.testTag("priya_service_switch")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = { DeviceController.openOverlayPermissionSettings(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = PriyaNavyButton),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, PriyaBrightBlue, RoundedCornerShape(14.dp))
                        .testTag("overlay_permission_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        tint = if (canDrawOverlays) Color(0xFF4CAF50) else PriyaCyanGlow,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (canDrawOverlays) "Overlay Ready" else "Allow Overlay",
                        fontSize = 12.sp
                    )
                }

                Button(
                    onClick = { DeviceController.requestIgnoreBatteryOptimizations(context) },
                    colors = ButtonDefaults.buttonColors(containerColor = PriyaNavyButton),
                    modifier = Modifier
                        .weight(1f)
                        .border(1.dp, PriyaBrightBlue, RoundedCornerShape(14.dp))
                        .testTag("battery_opt_button"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.BatteryChargingFull,
                        contentDescription = null,
                        tint = PriyaCyanGlow,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Unrestricted Battery", fontSize = 12.sp)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Section 3: Voice & Language Preferences
            Text(
                text = "Voice & Language Settings",
                style = MaterialTheme.typography.titleMedium,
                color = PriyaCyanGlow,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(10.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = null,
                                tint = PriyaCyanGlow
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Speak Replies Aloud (TTS)",
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color.White
                            )
                        }
                        Switch(
                            checked = autoSpeak,
                            onCheckedChange = onToggleAutoSpeak,
                            modifier = Modifier.testTag("tts_toggle_switch")
                        )
                    }

                    HorizontalDivider(
                        modifier = Modifier.padding(vertical = 12.dp),
                        color = Color.White.copy(alpha = 0.1f)
                    )

                    Text(
                        text = "Preferred Conversation Language",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF9EB2D4)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val languages = listOf("Hinglish / Multi", "Hindi (हिंदी)", "Bengali (বাংলা)", "English")
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        languages.forEach { lang ->
                            val selected = lang == languageMode
                            AssistChip(
                                onClick = { onSelectLanguageMode(lang) },
                                label = { Text(lang, color = Color.White) },
                                colors = AssistChipDefaults.assistChipColors(
                                    containerColor = if (selected) PriyaBrightBlue else PriyaNavyButton
                                ),
                                border = AssistChipDefaults.assistChipBorder(
                                    enabled = true,
                                    borderColor = if (selected) PriyaCyanGlow else PriyaBrightBlue.copy(alpha = 0.4f)
                                )
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Section 4: Quick App Launcher (Uses <queries> from AndroidManifest.xml)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Apps, contentDescription = null, tint = PriyaCyanGlow)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Installed Apps (${installedApps.size})",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                }
                Text(
                    text = "Tap to launch via Priya",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF9EB2D4)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            if (installedApps.isEmpty()) {
                Text(
                    text = "Say 'Priya, open Settings' or 'Open Browser'",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color(0xFF8DA0C4)
                )
            } else {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    items(installedApps.take(20)) { app ->
                        AssistChip(
                            onClick = {
                                onSendCommand("Priya, open ${app.label}")
                                onClose()
                            },
                            label = { Text(app.label, color = Color.White) },
                            colors = AssistChipDefaults.assistChipColors(containerColor = PriyaNavyButton)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Section 5: Quick Contacts Dialer (READ_CONTACTS & CALL_PHONE)
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Call, contentDescription = null, tint = PriyaCyanGlow)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Quick Contacts & Calling",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                }
                Button(
                    onClick = onRequestContactsPermission,
                    colors = ButtonDefaults.buttonColors(containerColor = PriyaBrightBlue),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("sync_contacts_button")
                ) {
                    Text("Sync Contacts", fontSize = 12.sp)
                }
            }

            if (contacts.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(contacts.take(15)) { contact ->
                        AssistChip(
                            onClick = {
                                onSendCommand("Priya, call ${contact.name}")
                                onClose()
                            },
                            label = { Text("${contact.name} (${contact.phoneNumber})", color = Color.White) },
                            colors = AssistChipDefaults.assistChipColors(containerColor = PriyaNavyButton)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
private fun ServiceStatusCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    isActive: Boolean,
    actionLabel: String,
    onActionClick: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131B2E))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isActive) Color(0xFF4CAF50) else PriyaCyanGlow,
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF9EB2D4)
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onActionClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isActive) Color(0xFF1B5E20) else PriyaBrightBlue
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                if (isActive) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                }
                Text(text = actionLabel, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun PriyaChatSheet(
    messages: List<ChatMessage>,
    voiceState: PriyaVoiceState,
    onSendMessage: (String) -> Unit,
    onClose: () -> Unit
) {
    BackHandler(onBack = onClose)
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .clickable(onClick = onClose)
    ) {
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .fillMaxHeight(0.78f)
                .clickable(enabled = false) {}
                .imePadding()
                .windowInsetsPadding(WindowInsets.navigationBars),
            color = Color(0xFF0E1525),
            shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.logo),
                            contentDescription = "Priya AI",
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .border(1.dp, PriyaCyanGlow, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Chat with Priya",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Voice, Hinglish, বাংলা, हिंदी & Phone Control",
                                style = MaterialTheme.typography.bodyMedium,
                                color = PriyaCyanGlow
                            )
                        }
                    }

                    IconButton(
                        onClick = onClose,
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(PriyaNavyButton)
                            .border(1.dp, PriyaBrightBlue, CircleShape)
                            .testTag("close_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close chat",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Quick Voice & Phone Control Suggestion Chips
                val quickCommands = listOf(
                    "Read my screen",
                    "Open Settings",
                    "Switch to Formal look",
                    "Switch to Street look",
                    "Volume Up",
                    "Tum kaun ho Priya?",
                    "Tell me a joke in Hinglish"
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(quickCommands) { cmd ->
                        AssistChip(
                            onClick = { onSendMessage(cmd) },
                            label = { Text(cmd, color = Color.White, fontSize = 12.sp) },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = PriyaNavyButton
                            ),
                            border = AssistChipDefaults.assistChipBorder(
                                enabled = true,
                                borderColor = PriyaBrightBlue.copy(alpha = 0.6f)
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Messages List
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(vertical = 8.dp)
                ) {
                    items(messages, key = { it.id }) { msg ->
                        val isUser = msg.sender == ChatMessage.Sender.USER
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                        ) {
                            Surface(
                                color = when (msg.sender) {
                                    ChatMessage.Sender.USER -> PriyaBrightBlue
                                    ChatMessage.Sender.PRIYA -> Color(0xFF1A253D)
                                    ChatMessage.Sender.SYSTEM -> Color(0xFF3E1F28)
                                },
                                shape = RoundedCornerShape(
                                    topStart = 18.dp,
                                    topEnd = 18.dp,
                                    bottomStart = if (isUser) 18.dp else 4.dp,
                                    bottomEnd = if (isUser) 4.dp else 18.dp
                                ),
                                modifier = Modifier.border(
                                    width = 1.dp,
                                    color = if (isUser) PriyaCyanGlow.copy(alpha = 0.5f)
                                    else PriyaBrightBlue.copy(alpha = 0.3f),
                                    shape = RoundedCornerShape(
                                        topStart = 18.dp,
                                        topEnd = 18.dp,
                                        bottomStart = if (isUser) 18.dp else 4.dp,
                                        bottomEnd = if (isUser) 4.dp else 18.dp
                                    )
                                )
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = msg.text,
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = Color.White
                                    )
                                    if (!msg.actionBadge.isNullOrBlank()) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = "⚡ ${msg.actionBadge}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = PriyaCyanGlow,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (voiceState is PriyaVoiceState.Thinking) {
                    Text(
                        text = "Priya is thinking...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = PriyaCyanGlow,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                // Input Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = inputText,
                        onValueChange = { inputText = it },
                        placeholder = {
                            Text(
                                text = stringResource(id = R.string.chat_placeholder),
                                color = Color(0xFF8DA0C4)
                            )
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PriyaCyanGlow,
                            unfocusedBorderColor = PriyaBrightBlue.copy(alpha = 0.5f),
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        ),
                        shape = RoundedCornerShape(24.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_message_input")
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    IconButton(
                        onClick = {
                            if (inputText.isNotBlank()) {
                                onSendMessage(inputText)
                                inputText = ""
                            }
                        },
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .background(PriyaBrightBlue)
                            .testTag("send_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = stringResource(id = R.string.send_message_desc),
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}
