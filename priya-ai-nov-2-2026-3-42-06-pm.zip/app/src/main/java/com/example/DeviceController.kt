package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.Settings
import androidx.core.content.ContextCompat

data class InstalledAppInfo(
    val label: String,
    val packageName: String
)

data class ContactEntry(
    val name: String,
    val phoneNumber: String
)

object DeviceController {

    fun getInstalledLauncherApps(context: Context): List<InstalledAppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        return resolveInfos
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                val label = info.loadLabel(pm)?.toString()?.trim().orEmpty()
                if (label.isNotEmpty() && pkg != context.packageName) {
                    InstalledAppInfo(label = label, packageName = pkg)
                } else null
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
    }

    fun launchAppByNameOrPackage(context: Context, query: String): Pair<Boolean, String> {
        val cleanQuery = query.trim().lowercase()
        if (cleanQuery.isEmpty()) return false to "App name not specified."

        val pm = context.packageManager
        val apps = getInstalledLauncherApps(context)

        val matched = apps.firstOrNull {
            it.label.lowercase() == cleanQuery || it.packageName.lowercase() == cleanQuery
        } ?: apps.firstOrNull {
            it.label.lowercase().contains(cleanQuery) || cleanQuery.contains(it.label.lowercase())
        } ?: apps.firstOrNull {
            it.packageName.lowercase().contains(cleanQuery)
        }

        if (matched != null) {
            val launchIntent = pm.getLaunchIntentForPackage(matched.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                return try {
                    context.startActivity(launchIntent)
                    true to "Opening ${matched.label}..."
                } catch (e: Exception) {
                    false to "Could not launch ${matched.label}: ${e.localizedMessage}"
                }
            }
        }

        // Common system fallbacks (Settings, Dialer, Browser, Camera)
        return when {
            cleanQuery.contains("setting") -> {
                val i = Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(i)
                true to "Opening Android Settings..."
            }
            cleanQuery.contains("youtube") || cleanQuery.contains("browser") || cleanQuery.contains("google") -> {
                val url = if (cleanQuery.contains("youtube")) "https://m.youtube.com" else "https://www.google.com"
                val i = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    context.startActivity(i)
                    true to "Opening $query..."
                } catch (e: Exception) {
                    false to "App '$query' is not installed on this device."
                }
            }
            else -> false to "App '$query' was not found on your phone."
        }
    }

    fun queryContacts(context: Context): List<ContactEntry> {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            return emptyList()
        }
        val list = mutableListOf<ContactEntry>()
        val resolver = context.contentResolver
        val cursor = resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null,
            null,
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC"
        )
        cursor?.use { c ->
            val nameIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numIdx = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (c.moveToNext() && list.size < 100) {
                val name = if (nameIdx >= 0) c.getString(nameIdx)?.trim().orEmpty() else ""
                val number = if (numIdx >= 0) c.getString(numIdx)?.trim().orEmpty() else ""
                if (name.isNotEmpty() && number.isNotEmpty()) {
                    list.add(ContactEntry(name, number))
                }
            }
        }
        return list.distinctBy { "${it.name}-${it.phoneNumber}" }
    }

    fun callContactOrNumber(context: Context, target: String): Pair<Boolean, String> {
        val cleaned = target.trim()
        if (cleaned.isEmpty()) return false to "Please tell me who to call."

        val contacts = queryContacts(context)
        val matchedContact = contacts.firstOrNull {
            it.name.equals(cleaned, ignoreCase = true) ||
                it.name.lowercase().contains(cleaned.lowercase())
        }

        val phoneNumber = matchedContact?.phoneNumber ?: cleaned.filter { it.isDigit() || it == '+' }
        if (phoneNumber.length < 3) {
            return if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                false to "Contacts permission is needed to find '$cleaned', or say the phone number."
            } else {
                false to "Could not find a contact named '$cleaned'."
            }
        }

        val hasCallPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED

        val intentAction = if (hasCallPerm) Intent.ACTION_CALL else Intent.ACTION_DIAL
        val callIntent = Intent(intentAction, Uri.parse("tel:$phoneNumber")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            context.startActivity(callIntent)
            val displayTarget = matchedContact?.name ?: phoneNumber
            true to if (hasCallPerm) "Calling $displayTarget now..." else "Opening dialer for $displayTarget..."
        } catch (e: Exception) {
            false to "Unable to place call: ${e.localizedMessage}"
        }
    }

    fun adjustVolume(context: Context, raise: Boolean): String {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return "Audio service unavailable."
        val direction = if (raise) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        audioManager.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            direction,
            AudioManager.FLAG_SHOW_UI
        )
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return "Volume set to $current / $max."
    }

    fun openAccessibilitySettings(context: Context) {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    fun openOverlayPermissionSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(intent)
            } catch (_: Exception) {
            }
        }
    }

    fun requestIgnoreBatteryOptimizations(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(intent)
            } catch (_: Exception) {
            }
        }
    }
}
