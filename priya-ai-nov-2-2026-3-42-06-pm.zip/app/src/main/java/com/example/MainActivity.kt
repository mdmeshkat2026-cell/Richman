package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.PoppinsFontFamily
import com.example.ui.theme.PriyaAITheme
import com.example.ui.theme.PriyaBrightBlue
import com.example.ui.theme.PriyaCyanGlow
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // STEP 1: Configure App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)

        enableEdgeToEdge()

        // STEP 2: Initialize UI
        setContent {
            PriyaAITheme {
                PriyaMainApp()
            }
        }
    }
}

private enum class ActiveOverlay {
    NONE,
    MENU,
    VISION,
    CHAT
}

@Composable
fun PriyaMainApp(
    viewModel: PriyaViewModel = viewModel()
) {
    val context = LocalContext.current

    val selectedAvatar by viewModel.selectedAvatar.collectAsStateWithLifecycle()
    val voiceState by viewModel.voiceState.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val lastBubble by viewModel.lastAssistantBubble.collectAsStateWithLifecycle()
    val autoSpeak by viewModel.autoSpeak.collectAsStateWithLifecycle()
    val languageMode by viewModel.languageMode.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val contacts by viewModel.contacts.collectAsStateWithLifecycle()

    val isAccessibilityConnected by PriyaAccessibility.isConnected.collectAsStateWithLifecycle()
    val isServiceRunning by PriyaService.isRunning.collectAsStateWithLifecycle()

    var activeOverlay by remember { mutableStateOf(ActiveOverlay.NONE) }

    var hasAudioPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
                PackageManager.PERMISSION_GRANTED
        )
    }
    var hasCameraPerm by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED
        )
    }

    val micPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.RECORD_AUDIO] == true
        hasAudioPerm = granted
        if (granted) {
            viewModel.startVoiceListening()
        }
    }

    val cameraPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPerm = granted
    }

    val contactsPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.refreshDeviceData()
    }

    val servicePermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms[Manifest.permission.RECORD_AUDIO] == true) {
            hasAudioPerm = true
            viewModel.toggleForegroundService(true)
        }
    }

    val isVoiceActive = voiceState is PriyaVoiceState.Listening ||
        voiceState is PriyaVoiceState.Speaking ||
        voiceState is PriyaVoiceState.Thinking

    val infiniteTransition = rememberInfiniteTransition(label = "ActivePulse")
    val pulseRadiusScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isVoiceActive) 1.16f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(750, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "PulseRadius"
    )

    // Single unified full-screen interface mapped directly onto the 720x1640 design artwork
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF151924))
    ) {
        val containerWidthPx = constraints.maxWidth.toFloat()
        val containerHeightPx = constraints.maxHeight.toFloat()

        // ContentScale.Crop math for 720 x 1640 source image
        val imgW = 720f
        val imgH = 1640f
        val scale = max(containerWidthPx / imgW, containerHeightPx / imgH)
        val scaledW = imgW * scale
        val scaledH = imgH * scale
        val offsetX = (containerWidthPx - scaledW) / 2f
        val offsetY = (containerHeightPx - scaledH) / 2f

        fun mapX(srcX: Float): Int = (offsetX + srcX * scale).roundToInt()
        fun mapY(srcY: Float): Int = (offsetY + srcY * scale).roundToInt()

        var dragDelta by remember { mutableFloatStateOf(0f) }

        // 1. Full-screen single unified interface artwork (with swipe left/right to switch outfits)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectHorizontalDragGestures(
                        onDragStart = { dragDelta = 0f },
                        onHorizontalDrag = { _, dragAmount ->
                            dragDelta += dragAmount
                        },
                        onDragEnd = {
                            if (dragDelta > 85f) {
                                viewModel.cycleAvatar(forward = false)
                            } else if (dragDelta < -85f) {
                                viewModel.cycleAvatar(forward = true)
                            }
                        }
                    )
                }
                .testTag("priya_avatar_stage")
        ) {
            AnimatedContent(
                targetState = selectedAvatar,
                transitionSpec = {
                    fadeIn(tween(280)) togetherWith fadeOut(tween(280))
                },
                label = "UnifiedSceneTransition"
            ) { avatar ->
                Image(
                    painter = painterResource(id = avatar.drawableRes),
                    contentDescription = avatar.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }

        // 2. Exact Interactive Hit-Target Overlays aligned with the single unified interface

        // Top-Left Hamburger Menu Button (Center at x=82, y=138, diameter=104 in 720x1640)
        val menuDesc = stringResource(id = R.string.menu_button_desc)
        Box(
            modifier = Modifier
                .offset {
                    IntOffset(
                        x = mapX(82f - 56f),
                        y = mapY(138f - 56f)
                    )
                }
                .size(64.dp)
                .clip(CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = PriyaCyanGlow),
                    role = Role.Button,
                    onClick = { activeOverlay = ActiveOverlay.MENU }
                )
                .semantics { contentDescription = menuDesc }
                .testTag("menu_button")
        )

        // Top Center "Priya" Header Tap Target (Tapping the header/waveform cycles Priya's 3 outfits)
        Box(
            modifier = Modifier
                .offset {
                    IntOffset(
                        x = mapX(185f),
                        y = mapY(80f)
                    )
                }
                .size(width = 180.dp, height = 75.dp)
                .clip(RoundedCornerShape(20.dp))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = PriyaCyanGlow),
                    role = Role.Button,
                    onClick = { viewModel.cycleAvatar(forward = true) }
                )
                .semantics { contentDescription = "Switch Priya Outfit" }
                .testTag("switch_outfit_chip")
        )

        // Bottom-Left Camera Button (Center at x=206, y=1412 in 720x1640)
        val cameraDesc = stringResource(id = R.string.camera_button_desc)
        Box(
            modifier = Modifier
                .offset {
                    IntOffset(
                        x = mapX(206f - 52f),
                        y = mapY(1412f - 52f)
                    )
                }
                .size(62.dp)
                .clip(CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = PriyaCyanGlow),
                    role = Role.Button,
                    onClick = { activeOverlay = ActiveOverlay.VISION }
                )
                .semantics { contentDescription = cameraDesc }
                .testTag("camera_button")
        )

        // Bottom-Center Glowing Microphone Button (Center at x=360, y=1412 in 720x1640)
        val micDesc = stringResource(id = R.string.mic_button_desc)
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .offset {
                    IntOffset(
                        x = mapX(360f - 82f),
                        y = mapY(1412f - 82f)
                    )
                }
                .size(96.dp)
                .clip(CircleShape)
                .then(
                    if (isVoiceActive) {
                        Modifier.border(
                            width = (3.5f * pulseRadiusScale).dp,
                            color = PriyaCyanGlow,
                            shape = CircleShape
                        )
                    } else {
                        Modifier
                    }
                )
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = PriyaCyanGlow),
                    role = Role.Button,
                    onClick = {
                        if (voiceState is PriyaVoiceState.Listening || voiceState is PriyaVoiceState.Speaking) {
                            viewModel.stopSpeakingOrListening()
                        } else if (hasAudioPerm) {
                            viewModel.startVoiceListening()
                        } else {
                            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                perms.add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            micPermLauncher.launch(perms.toTypedArray())
                        }
                    }
                )
                .semantics { contentDescription = micDesc }
                .testTag("mic_button")
        ) {}

        // Bottom-Right Chat Button (Center at x=514, y=1412 in 720x1640)
        val chatDesc = stringResource(id = R.string.chat_button_desc)
        Box(
            modifier = Modifier
                .offset {
                    IntOffset(
                        x = mapX(514f - 52f),
                        y = mapY(1412f - 52f)
                    )
                }
                .size(62.dp)
                .clip(CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = ripple(bounded = true, color = PriyaCyanGlow),
                    role = Role.Button,
                    onClick = { activeOverlay = ActiveOverlay.CHAT }
                )
                .semantics { contentDescription = chatDesc }
                .testTag("chat_button")
        )

        // 3. Live Voice Status Pill & Reply Bubble (Shown ONLY when active or when Priya replies)
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars)
                .padding(horizontal = 24.dp, vertical = 180.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val activeStatusText = when (val state = voiceState) {
                is PriyaVoiceState.Idle -> null
                is PriyaVoiceState.Listening -> state.partialText.ifBlank {
                    stringResource(id = R.string.listening_now)
                }
                is PriyaVoiceState.Thinking -> stringResource(id = R.string.thinking_now)
                is PriyaVoiceState.Speaking -> stringResource(id = R.string.speaking_now)
                is PriyaVoiceState.Error -> state.message
            }

            val bubbleText = activeStatusText ?: lastBubble

            AnimatedVisibility(
                visible = !bubbleText.isNullOrBlank(),
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Surface(
                    color = Color(0xE60A1326),
                    shape = RoundedCornerShape(22.dp),
                    modifier = Modifier
                        .widthIn(max = 460.dp)
                        .border(
                            1.5.dp,
                            PriyaCyanGlow.copy(alpha = 0.7f),
                            RoundedCornerShape(22.dp)
                        )
                        .clickable { activeOverlay = ActiveOverlay.CHAT }
                        .testTag("assistant_response_bubble")
                ) {
                    Row(
                        modifier = Modifier.padding(start = 16.dp, top = 10.dp, bottom = 10.dp, end = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = bubbleText.orEmpty(),
                            fontFamily = PoppinsFontFamily,
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp,
                            color = Color.White,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis,
                            textAlign = TextAlign.Start,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = {
                                viewModel.stopSpeakingOrListening()
                                viewModel.dismissAssistantBubble()
                            },
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Dismiss message",
                                tint = PriyaCyanGlow,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }

        // 4. Full-screen Sheets (Menu, Vision Camera, Chat)
        when (activeOverlay) {
            ActiveOverlay.MENU -> {
                PriyaMenuSheet(
                    selectedAvatar = selectedAvatar,
                    onSelectAvatar = {
                        viewModel.selectAvatar(it)
                        activeOverlay = ActiveOverlay.NONE
                    },
                    isAccessibilityConnected = isAccessibilityConnected,
                    isServiceRunning = isServiceRunning,
                    onToggleService = { enable ->
                        if (enable && !hasAudioPerm) {
                            val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                perms.add(Manifest.permission.POST_NOTIFICATIONS)
                            }
                            servicePermLauncher.launch(perms.toTypedArray())
                        } else {
                            viewModel.toggleForegroundService(enable)
                        }
                    },
                    autoSpeak = autoSpeak,
                    onToggleAutoSpeak = { viewModel.toggleAutoSpeak(it) },
                    languageMode = languageMode,
                    onSelectLanguageMode = { viewModel.setLanguageMode(it) },
                    installedApps = installedApps,
                    contacts = contacts,
                    onRequestContactsPermission = {
                        contactsPermLauncher.launch(
                            arrayOf(
                                Manifest.permission.READ_CONTACTS,
                                Manifest.permission.CALL_PHONE
                            )
                        )
                    },
                    onSendCommand = { cmd -> viewModel.sendUserCommandOrMessage(cmd) },
                    onClose = { activeOverlay = ActiveOverlay.NONE }
                )
            }

            ActiveOverlay.VISION -> {
                PriyaVisionSheet(
                    hasCameraPermission = hasCameraPerm,
                    onRequestCameraPermission = {
                        cameraPermLauncher.launch(Manifest.permission.CAMERA)
                    },
                    onAnalyzeBitmap = { bmp, question ->
                        viewModel.analyzeCameraImage(bmp, question)
                    },
                    onClose = { activeOverlay = ActiveOverlay.NONE }
                )
            }

            ActiveOverlay.CHAT -> {
                PriyaChatSheet(
                    messages = messages,
                    voiceState = voiceState,
                    onSendMessage = { msg -> viewModel.sendUserCommandOrMessage(msg) },
                    onClose = { activeOverlay = ActiveOverlay.NONE }
                )
            }

            ActiveOverlay.NONE -> Unit
        }
    }
}
